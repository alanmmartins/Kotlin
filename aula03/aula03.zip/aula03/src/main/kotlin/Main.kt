fun main(args: Array<String>)
{
//    var usuario : usuario();
//    usuario.nome = "Lucas"
//    usuario.email = = "lucasemil.com"
//    usuario.idade = 30
//    usuario.senha = "123"
//
//    var usuario02 : usuario();
//    usuario02.nome = "Miguel"
//    usuario02.idade = 30
//    usuario02.senha="123"


    var novoCarro = carro (
        "abc1234",
         "Celta",
          "Chervolet")
    println(novoCarro.marca,)


}