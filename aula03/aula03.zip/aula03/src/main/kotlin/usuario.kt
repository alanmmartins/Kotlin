class usuario
{
    //todos os usuarios do meu sistema vai ter as
    //propriedades e metodos de um usuario

    var nome : String = "";
    var email : String = "";
    var idade : String = "";
    var senha : String = "";

    fun NomeEEmail():String
    {
        return nome + "e o email"+email+ "e a idade" + idade;
    }
    fun MudarSenha( novaSenha:String)
    {
        senha = novaSenha
    }
}
