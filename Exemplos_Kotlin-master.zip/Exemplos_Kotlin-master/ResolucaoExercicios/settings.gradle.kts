
rootProject.name = "ResolucaoExercicios"

