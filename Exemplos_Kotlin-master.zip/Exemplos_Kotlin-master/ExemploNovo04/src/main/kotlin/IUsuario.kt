interface IUsuario
{
    fun Logar()
}