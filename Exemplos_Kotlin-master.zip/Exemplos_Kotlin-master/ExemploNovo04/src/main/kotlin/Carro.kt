class Carro : Automovel()
{
    var qtdPortas : Int = 4;

    fun QuantidadeRodas()
    {
        qtdRodas
    }

    fun AbrirPorta()
    {
        println("Abriuuu")
    }

    fun Abastecer(){

    }
}