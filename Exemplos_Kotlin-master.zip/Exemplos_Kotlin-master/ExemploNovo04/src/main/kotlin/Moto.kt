class Moto : Automovel()
{

    fun Grau()
    {
        println("bolooolooo")
    }
}