
rootProject.name = "ResolucaoExercicios02"

