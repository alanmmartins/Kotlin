class MediaAluno
{
    var nomeAluno : String;
    var mediaAluno : Float;

    constructor(nomeAluno: String, mediaAluno: Float)
    {
        this.nomeAluno = nomeAluno;
        this.mediaAluno = mediaAluno;
    }
}