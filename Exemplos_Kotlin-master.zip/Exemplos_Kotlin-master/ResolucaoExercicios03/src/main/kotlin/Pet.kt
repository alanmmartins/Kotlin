class Pet
{
    var nomePet : String;
    var raca : String;
    var idade : Int;

    constructor(nomePet: String, raca : String, idade : Int)
    {
        this.nomePet = nomePet
        this.raca = raca
        this.idade = idade
    }

    fun Falar(fala : String)
    {

    }
}