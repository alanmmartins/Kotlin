class Calculadora
{
    var valor1: Double = 0.00;
    var valor2: Double = 0.00;
    var valor3: Double = 0.00;
    var result: Double = 0.00;

    fun Somar(valorx : Double, valory : Double) : Double
    {
        return valorx + valory;
    }
}