package com.example.exemplocrud

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*

class MainActivity : AppCompatActivity() {

    // nossa lista
    private lateinit var listView: ListView //começar com valor inicial inteiro 0
    private lateinit var campoNome: EditText
    private lateinit var campoEmail: EditText

// Posição lista

    private var positionList = -1; //


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//identificar a lista
        listView = findViewById(R.id.listaUsuarios)

// receber os 3 botões

        var btn_cadastrar = findViewById<Button>(R.id.btn_cadastrar)
        var btn_alterar = findViewById<Button>(R.id.btn_alterar)
        var btn_excluir = findViewById<Button>(R.id.btn_remover)

// recebr os dois campos

         campoNome = findViewById<EditText>(R.id.Nome) // R = pasta res
         campoEmail = findViewById<EditText>(R.id.Email)

// instanciar lista de usuarios

        var listaDeUsuarios = ArrayList<Usuario>();

        listaDeUsuarios.add(Usuario("Exemplo", "exemplo@gmail.com"))
        ListarUsuarios(listaDeUsuarios)

//pega o item clicado na lista
        listView.setOnItemClickListener { _, _, position, _ ->

            //Toast.makeText(this, "$position", Toast.LENGTH_SHORT).show()
            positionList = position
            campoNome.setText(listaDeUsuarios[position].nome)
            campoEmail.setText(listaDeUsuarios[position].email)


        }


// ler a lista e exibir
        btn_cadastrar.setOnClickListener()
        {
            var novoUsuario = Usuario(campoNome.text.toString(), campoEmail.text.toString())
            listaDeUsuarios.add(novoUsuario)

            ListarUsuarios(listaDeUsuarios)
            LimparCampos()
        }

        btn_alterar.setOnClickListener()
        {
            if( positionList >= 0 )
            listaDeUsuarios[positionList].nome = campoNome.text.toString()
            listaDeUsuarios[positionList].email = campoNome.text.toString()

            ListarUsuarios(listaDeUsuarios)
            LimparCampos()
        }

        btn_excluir.setOnClickListener()
        {
            if (positionList >= 0)
            listaDeUsuarios.removeAt(positionList)

            ListarUsuarios(listaDeUsuarios)
            LimparCampos()
        }



    }

    fun ListarUsuarios(listaDeUsuarios: ArrayList<Usuario>)
    {
        var adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, listaDeUsuarios)
        listView.adapter = adapter
    }

    fun LimparCampos(){

        positionList = -1
        campoNome.setText("")
        campoEmail.setText("")

    }
}
